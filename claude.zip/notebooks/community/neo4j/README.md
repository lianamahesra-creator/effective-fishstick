# README

These are notebooks [Neo4j](https://neo4j.com/) built in collaboration with Google.  They show how to use Neo4j's Graph Database and Graph Data Science with GCP Vertex AI.